---------------------------------------------------------------------------
UltraMenu: README
---------------------------------------------------------------------------

Please read this file carefully (especially "Installation" chapter) before 
installing the program to your computer.

---------------------------------------------------------------------------
Contents
---------------------------------------------------------------------------

  Program information
  Company information
  Description
  Installation and uninstallation
  History
  Registration
  Copyright and license
  Technical support

---------------------------------------------------------------------------
Program information
---------------------------------------------------------------------------

Program Archive Name:
  ultramenu.exe
Program Name:
  UltraMenu
Program Version:
  1.1
Program Release Date:
  May 8, 2008
System Requirement:
  Windows 98/ME/2000/XP/2003/Vista
Software Type:
  Shareware ($39.95)

---------------------------------------------------------------------------
Company information
---------------------------------------------------------------------------

Company Name:
  AntsSoft Inc.
Contact E-mail Address:
  support@antssoft.com
Contact WWW URL:
  http://www.antssoft.com/
Contact Postal Address:
  Room 1002, No 21, Lane 675, GuMei Road
  201102, Shanghai
  PR China
  
---------------------------------------------------------------------------
Description
---------------------------------------------------------------------------

UltraMenu is a DHTML/JavaScript web menu builder. With its help, you can 
easily complete the creation of navigation menus for a web site even without 
any development experience related to DHTML or JavaScript. It can generate 
cross-browser pop-up or drop-down menus compatible with all popular browsers 
including Internet Explorer, FireFox, Netscape Navigator, Opera, Mozilla, 
Konqueror, Safari and Camino, etc. UltraMenu supports hierarchical menus, and 
you can customize such attributes as layout, text, font style, link, 
background, border, animation effects, etc. for menus, menu groups and menu 
items separately based on your requirements. After you have completed the 
design of a menu, you can add it into your web pages by UltraMenu's Publish 
Wizard in a breeze. UltraMenu will save you a significant amount of time and 
effort required to fully understand DHTML and JavaScript code capable to 
support all DHTML-enabled browsers!

---------------------------------------------------------------------------
Installation and uninstallation
---------------------------------------------------------------------------

Important! If you've got UltraMenu not from our web page, but from the other 
source (magazine CD or some software library), please visit our home page 
- you'll probably find the later version; 

To install UltraMenu, just open the "ultramenu.zip", run "setup.exe" and 
follow the instructions. You'll need to select the target directory and 
program group name to install.

To uninstall UltraMenu, just open control panel, double-click the Add/Remove 
Programs icon. Select "UltraMenu", then click Add/Remove and follow the 
instructions.

---------------------------------------------------------------------------
History
---------------------------------------------------------------------------

See "history.txt" file.

---------------------------------------------------------------------------
Registration
---------------------------------------------------------------------------

See "order.txt" file.

---------------------------------------------------------------------------
Copyright and license
---------------------------------------------------------------------------

See "license.txt" file.

---------------------------------------------------------------------------
Technical support
---------------------------------------------------------------------------

If you would like to download the latest version of UltraMenu, read product 
information or register this program, please visit our website at 
http://www.antssoft.com/

Our technical support staff will provide timely service with any problems 
you encounter with our software. When seeking technical support, please 
provide the following information with your requests:  

  . The installed version of UltraMenu 
  . The installed operating system and version 
  . Full details of the problem you encounter, And if possible include 
    steps on how to reproduce the problem 
  . If you are a registered user, include your registration code and our 
    technical support staff will give your request priority.  

To get more help from our technical support staff, you can contact us 
through e-mail: support@antssoft.com. We would also appreciate any 
comments or suggestions you may have about our software.

