fixMozillaZIndex=true; //Fixes Z-Index problem  with Mozilla browsers but causes odd scrolling problem, toggle to see if it helps
_menuCloseDelay=500;
_menuOpenDelay=150;
_subOffsetTop=2;
_subOffsetLeft=-2;




with(menuStyle=new mm_style()){
bordercolor="black";
borderstyle="solid";
borderwidth=1;
fontfamily="Verdana, Tahoma, Arial";
fontsize="75%";
fontstyle="normal";
headerbgcolor="black";
headercolor="black";
offbgcolor="black";
offcolor="black";
onbgcolor="black";
oncolor="gold";
outfilter="randomdissolve(duration=0.3)";
overfilter="Fade(duration=0.2);Alpha(opacity=90);Shadow(color=#777777', Direction=135, Strength=3)";
padding=4;
pagebgcolor="#82B6D7";
pagecolor="black";
separatorcolor="#999999";
separatorsize=1;
subimage="http://img.milonic.com/arrow.gif";
subimagepadding=2;
}

with(milonic=new menuname("Main Menu")){
alwaysvisible=1;
orientation="horizontal";
style=menuStyle;
aI("text=Home;url=http://www.milonic.com/;");
aI("showmenu=1st Year;text=1st Year;");
aI("showmenu=2nd Year;text=2nd Year;");
aI("showmenu=3rd Year;text=3rd Year;");
}

with(milonic=new menuname("1st Year")){
overflow="scroll";
style=menuStyle;
aI("text=1st Semester;url=http://www.milonic.com/menusample1.php;")
aI("text=2nd Semester;url=http://www.milonic.com/menusample1.php;")
}

with(milonic=new menuname("2nd Year")){
overflow="scroll";
style=menuStyle;
aI("text=1st Semester;url=http://www.milonic.com/menusample1.php;")
aI("text=2nd Semester;url=http://www.milonic.com/menusample1.php;")
}

with(milonic=new menuname("3rd Year")){
overflow="scroll";
style=menuStyle;
aI("text=1st Semester;url=http://www.milonic.com/menusample1.php;")
aI("text=2nd Semester;url=http://www.milonic.com/menusample1.php;")
}

drawMenus();

