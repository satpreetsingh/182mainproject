//========================================================================
// SCRIPT:   jspframework.js
// Purpose: Contains JavaScript functions to support the JSP framework.
//
// Author:  Wayne Hsu, Field Application Engineer, SilverStream Software 
//

var i = 1;
var vFieldList = new Array();	// To store the information of the validation fields.
var btnList = new Array();	// To store the information of the buttons.

//=========================================================================
//  Function vField(fieldObj, fieldLabel, isRequired, dataType)  
//  Purpose: A JavaScript Object that holds the page validation information
//  Arguments: 	fieldObject : the page control that you want to validate
//		fieldLabel : the label of the page control that will show up in the error message to the user
//		isRequired : indicates whether the control is a required field
//		dataType : Data type of the control. 
function vField(fieldObj, fieldLabel, isRequired, dataType)
{
	this.fieldObj = fieldObj;
	this.fieldLabel = fieldLabel;
	this.isRequired = isRequired;
	this.dataType = dataType;
}

//=========================================================================
//  Function vButton(btnName, isValidate, isConfirm, Message)  
//  Purpose: A JavaScript Object that holds the button information
//  Arguments: 	btnName : the name of the button
//		isValidate : indicates whether this button invokes the validation functions.
//		isConfirm : indicates if the submit action needs to be confirmed by the user.
//		Message : the message for the confirmation message box. 
function vButton(btnName, isValidate, isConfirm, Message)
{
	this.btnName = btnName;
	this.isValidate = isValidate;
	this.isConfirm = isConfirm;
	this.Message = Message;
}

//=========================================================================
//  Function addVFields(fieldObj, fieldLabel, isRequired, dataType) 
//  Purpose: Add a page control to the validation list
//  Arguments: 	fieldObject : the page control that you want to validate
//		fieldLabel : the label of the page control that will show up in the error message to the user
//		isRequired : indicates whether the control is a required field
//		dataType : Data type of the control. 
function addVFields(fieldObj, fieldLabel, isRequired, dataType)
{
	vFieldList[i] = new vField(fieldObj, fieldLabel, isRequired, dataType);
	i++;
}

//=========================================================================
//  Function addButtons(btnName, isValidate, isConfirm, Message) 
//  Purpose: Add a button to the button list
//  Arguments: 	btnName : the name of the button
//		isValidate : indicates whether this button invokes the validation functions.
//		isConfirm : indicates if the submit action needs to be confirmed by the user.
//		Message : the message for the confirmation message box. 
function addButtons(btnName, isValidate, isConfirm, Message)
{
	btnList[btnName] = new vButton(btnName, isValidate, isConfirm, Message);
}

//=========================================================================
//  Function pageValidate() 
//
//  Purpose: Validate the fields registered through the addVFields function
//  		modify this function to suit your needs            
function pageValidate()
{
	var errMessage = "";
	var dobPattern = /\d{2}\/\d{2}\/\d{4}/;
	var timePattern = /\d{2}\d{2}/;
	var yesnoPattern = /[YyNn]/;
	var ddd, yyyy, hh, mm;
	var amIempty;
       
	for (var q=1; q<vFieldList.length; q++)
	{
		fld = eval("document.forms[0].elements['" + vFieldList[q].fieldObj + "']");
		value = fld.value;
		
		if ( isEmpty(fld) )
		{
			if (vFieldList[q].isRequired)
			{
				errMessage += vFieldList[q].fieldLabel + " is required\n";
			}
			else
				;
		}
		else
		{	
			switch (vFieldList[q].dataType)
			{
			case "INTEGER":
			{
				if (value.indexOf('.')>=0||isNaN(parseInt(value)))
					errMessage += vFieldList[q].fieldLabel + " is not an integer\n";
				break;
			}
			case "NUMBER":
			{
				if (isNaN(parseFloat(value)))
					errMessage += vFieldList[q].fieldLabel + " is not a number\n";
				break;
			}
			case "TIME": //time
			{
				if (timePattern.test(value))
				{
					hh = parseInt(value.substr(0, 2), 10);
					mm = parseInt(value.substr(2, 2), 10);
					if (hh<0 || hh>24 || mm<0 || mm>60)
						errMessage += "Please enter 'hhmm' for " + vFieldList[q].fieldLabel +"\n";
				}
				else
					errMessage += "Please enter 'hhmm' for " + vFieldList[q].fieldLabel +"\n";

				break;
			}
			case "DATE":
			{
				if (dobPattern.test(value))
				{
					mm = parseInt(value.substr(0, 2), 10);
					dd = parseInt(value.substr(3, 2), 10);
					yyyy = parseInt(value.substr(6, 4), 10);
					if (dd<1 || dd> 31 || yyyy<1 || mm<0 || mm>12)
						errMessage += "Please enter 'mm/dd/yyyy' for " + vFieldList[q].fieldLabel +"\n";
					
				}
				else
					errMessage += "Please enter 'mm/dd/yyyy' for " + vFieldList[q].fieldLabel +"\n";
				break;
			}
			case "YESNO":
			{
				if (!yesnoPattern.test(value))
					errMessage += "Please enter 'Y or N' for " + vFieldList[q].fieldLabel +"\n";
				break;
			}
			default:
			{	
				break;
			}
			}
		}
	}
	if (errMessage != "")
	{
		alert(errMessage);
		return false;
	}
	else
	{
		return true;
	}
}

//=========================================================================
//  Function isEmpty(tempobj) 
//  Purpose: Check if the value of the passed in object is empty or not           
function isEmpty(tempobj) {
	return (((tempobj.type=="text"||tempobj.type=="textarea")&&
	tempobj.value=='')||(tempobj.type.toString().charAt(0)=="s"&&
	tempobj.selectedIndex==0)||(tempobj.type=="hidden"&&tempobj.value==' '))
 }

//=========================================================================
//  Function jsButtonSubmit(name) 
//  Purpose: perform the framework's javascript validate and/or
//	 button confirmation before calling document.forms[0].submit() function          
function jsButtonSubmit(name) {
	if (btnList[name].isValidate)
		if (!pageValidate())
			return;
	if (btnList[name].isConfirm)
		if (!confirm("Are you sure you want to " + btnList[name].Message + " ?"))
			return;
	
	document.forms[0].submit();
}

//=========================================================================
//  Function onerror  
//  Purpose: Displays a Browser Window that notify user of the JavaScript Error
//             
function onerror(msg, URL, lineNum)
{
	var errWindow = window.open("", "errors", "height=270,width=400")
	var wintxt = "<HTML><BODY><P>A JavaScript error has occurred."
	wintxt += "<TEXTAREA COLS=45 ROWS=8 WRAP=VIRTUAL>"
	wintxt += "Error: " + msg + "\n"
	wintxt += "Line: " + lineNum + "\n</TEXTAREA></BODY></HTML>"
	errWindow.document.write(wintxt)
	errWindow.document.close()
	return true
}

	
