<%@ taglib uri="taglib.tld" prefix="j" %>

<j:jscall name="quizLabel" url="test.jsp"/>


<form>
  <input name="b1" type="label" value="Test" onClick="f('Tested')">
</form>