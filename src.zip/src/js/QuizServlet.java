import beans.EssayBean;
import java.util.*;
import java.io.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import java.util.regex.*;
import jxl.*;
import jxl.read.biff.BiffException;
import javax.mail.MessagingException;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.mail.*;
import javax.mail.internet.*;
import java.lang.*;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
public class QuizServlet extends HttpServlet{
    String des;
  public HttpSession session;

  private static final String SMTP_HOST_NAME= "mail.stmp.host";
  private static final String SMTP_AUTH_USER = "dsouzma";
  private static final String SMTP_AUTH_PWD  = "pepsiblu";

  private static final String emailMsgTxt      = "Online Order Confirmation Message. ";
  private static final String emailSubjectTxt  = "Order Confirmation Subject";
  private static final String emailFromAddress = "dsouzma@gmail.com";
   private PreparedStatement getAll,delMessage;


  private String[] emailList = {"dsouzma@gmail.com"};

    public String getSMTP_AUTH_PWD() {
        return SMTP_AUTH_PWD;
    }

    public String getSMTP_AUTH_USER() {
        return SMTP_AUTH_USER;
    }

    public String getSMTP_HOST_NAME() {
        return SMTP_HOST_NAME;
    }

    public String getEmailFromAddress() {
        return emailFromAddress;
    }

    public String[] getEmailList() {
        return emailList;
    }

    public String getEmailMsgTxt() {
        return emailMsgTxt;
    }

    public String getEmailSubjectTxt() {
        return emailSubjectTxt;
    }

    public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException

    {
        session=request.getSession();
session.setAttribute("session", session);
response.setContentType("text/html;charset=UTF-8");

 
        
if(request.getParameter("uip_ticket")!=null){ // check if user is a valid person
    session=request.getSession();
session.setAttribute("session", session);
String uip_ticket=request.getParameter("uip_ticket");
            try {
        URL uipUrl = new URL("http://login.uiowa.edu/uip/checkticket.page?service=" +
                "http://localhost:8084/XmlQuiz/QuizServlet"+"&uip_ticket="+uip_ticket);
        URLConnection uc = uipUrl.openConnection();
        Properties props = new Properties();
        uc.setRequestProperty( "Connection", "close" );
        props.load(uc.getInputStream());
        String hawkid = props.getProperty("hawkid");
        session.setAttribute("hawkid", hawkid);
        ArrayList user=getUser(hawkid);
                if(!user.isEmpty()&&user.get(0).equals(hawkid)){ // check if user is in the KiLab database
                    String fname=user.get(1).toString();
                    String lname=user.get(2).toString();
                    session.setAttribute("fname", fname);
                    session.setAttribute("lname", lname);
                    ArrayList essays=new ArrayList();
                essays = getEssays(hawkid, null, null, null, null);
                session.setAttribute("essays", essays);
                    des="myhomePage.jsp";
                }
                else{   // user not found in KiLab, prompt the user to take the survey
                    des="survey.jsp";
                }
                }    catch (SQLException ex) {
                    ex.printStackTrace();
                } catch (ClassNotFoundException ex) {
                    ex.printStackTrace();
                } catch (java.text.ParseException ex) {
                    ex.printStackTrace();
                }
}

else if(request.getParameter("ContinuetoQuiz")!=null)
        {
           String year=request.getParameter("year");
        String semester=request.getParameter("semester");
        String lessonNumber=request.getParameter("lesson");
String choice=request.getParameter("choice");
String questType=request.getParameter("quest");
            createQuiz(year,semester,lessonNumber,choice,questType);
        }

else if(request.getParameter("getEssays")!=null){
String hawkid=(String) session.getAttribute("hawkid");
   String keywords=request.getParameter("keywords");
    String startdate=(String)request.getParameter("startDate");
    String enddate=(String)request.getParameter("endDate");
    String graded=request.getParameter("selectgraded");

               try {
                ArrayList essays= getEssays(hawkid,keywords, startdate, enddate, graded);
                session.setAttribute("essays",essays);
                if(essays==null&&essays.isEmpty()){
                    des="getEssayError.jsp";
                }
                else{
                    System.out.println("essays in getEssays="+essays.size());
                    des="instructorHomePage.jsp";
                }
           } catch (SQLException ex) {
                ex.printStackTrace();
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            } catch (java.text.ParseException ex) {
                    ex.printStackTrace();
            }
}

else if(request.getParameter("submitSurvey")!=null&&!session.isNew()){
    String hawkid=(String) session.getAttribute("hawkid");
    
            try {
                if(hawkid!=null){
                    String fname=(String) request.getParameter("fname");
                    String lname=(String) request.getParameter("lname");
                    session.setAttribute("fname", fname);
                    session.setAttribute("lname", lname);
   String gender=request.getParameter("gender");
    String studentYear=request.getParameter("studentYear");
    String duration=request.getParameter("duration");
    String fluency=request.getParameter("fluency");
    String friends=request.getParameter("friends");
    String family=request.getParameter("family");
    String yourself=request.getParameter("yourself");
                addUser(hawkid,fname,lname,gender, studentYear, duration, fluency, friends, family, yourself);
                }
                } catch (SQLException ex) {
                ex.printStackTrace();
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }
des="completedsurvey.jsp";
            }
else if(request.getParameter("submitEssay")!=null&&!session.isNew()){
/*Change the following line when UILogin Tools is implementted to get the HawkID*/
        /*Change the following line when UILogin Tools is implementted to get the HawkID*/
        String hawkID="mfdsouza";
        String Year=(String) session.getAttribute("Year");
        String Semester=(String) session.getAttribute("Semester");
        Calendar cal = Calendar.getInstance();
         java.util.Date date = cal.getTime();
         long millis = date.getTime();
         Timestamp timesubmitted=new Timestamp(millis);
         String korean= (String) session.getAttribute("korean");
         String english=(String) session.getAttribute("english");
         
            try {
                addEssay(Year, Semester, hawkID,timesubmitted,english,korean);
                    sendMail(Year,Semester,"mfdsouza");

            }catch (SQLException ex) {
                    ex.printStackTrace();
                } catch (ClassNotFoundException ex) {
                    ex.printStackTrace();
                }
             catch (Exception ex) {
                ex.printStackTrace();
            }

         des="essayResult.jsp";
}

         else if(request.getParameter("submitGrade")!=null&&!session.isNew()){
         Calendar cal = Calendar.getInstance();
         java.util.Date date = cal.getTime();
         long millis = date.getTime();
         Timestamp timecorrected = new Timestamp(millis);
         String correctedEnglish=(String) session.getAttribute("correctedEnglish");
         String correctedKorean=(String) session.getAttribute("correctedKorean");
         float grade=Float.parseFloat(session.getAttribute("grade").toString());
         String mid=(String)session.getAttribute("mid");
            try {
                addGradedEssay(Integer.parseInt(mid),timecorrected, correctedEnglish, correctedKorean,grade);
            } catch (SQLException ex) {
                ex.printStackTrace();
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }
          des="essayResult.jsp";
         
         }

         else{
         }
         response.setContentType("text/html; charset=UTF-8");
         RequestDispatcher disp=request.getRequestDispatcher(des);
     disp.forward(request,response);
 }
    public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
    {
       
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
       session=request.getSession();
SMTPAuthenticator smtpMailAuth;

       if(request.getParameter("submitTF")!=null){
                 ArrayList responses=new ArrayList();
                 ArrayList answers=(ArrayList) session.getAttribute("answers");
             
                 for(int i=0;i<answers.size();i++){
                      if(request.getParameter("ans"+i)!=null){
                        responses.add(request.getParameter("ans"+i).toString());
                        }
                        else{
                        responses.add("No response.");
                        }
                    }
                    
                    session.setAttribute("responses", responses);
                 des="tf_results.jsp";
            }
       else if(request.getParameter("submitMC")!=null){

                 ArrayList responses=new ArrayList();
                 ArrayList list=(ArrayList) session.getAttribute("list");
                 for(int i=0;i<list.size()-4;i++){
                      if(i%4==0){
                          int unanswered = 0;
                          for(int j=i;j<i+4;j++){
                              unanswered++;
                        if(request.getParameter("a"+j)!=null){
                        responses.add(request.getParameter("a"+j).toString());
                        unanswered=0;
                        }
                        else{
                                  if(unanswered==4){
                         responses.add("No response.");
                        unanswered=0;
                        }
                      }
                    }
                    }
                    }
               session.setAttribute("responses", responses);
                 des="mc_results.jsp";
            }
else if(request.getParameter("submitFIB")!=null){
             ArrayList responses=new ArrayList();
                 ArrayList list=(ArrayList) session.getAttribute("list");
                 for(int i=0;i<list.size()-4;i++){
                      if(i%4==0){
                          int unanswered = 0;
                          for(int j=i;j<i+4;j++){
                              unanswered++;
                        if(request.getParameter("a"+j)!=null){
                        responses.add(request.getParameter("a"+j).toString());
                        unanswered=0;
                        }
                        else{
                                  if(unanswered==4){
                         responses.add("No response.");
                        unanswered=0;
                        }
                      }
                    }
                    }
                    }
                 session.setAttribute("responses", responses);
                 des="fib_results.jsp";
                }

       else if(request.getParameter("goBack")!=null){
           des="gradeEssays.jsp";
       }

       else{}

        RequestDispatcher disp=request.getRequestDispatcher(des);
        disp.forward(request,response);

    }

    public void createQuiz(String year,String semester,String lessonNumber,String choice,String questType) throws IOException{
        String fileName="C:/Users/Mark/Documents/NetBeansProjects/XmlQuiz/web/KoreanFinalFiles/K";
        if(Integer.parseInt(lessonNumber)<10){
            fileName=fileName+""+year+semester+"0"+lessonNumber+".xls";

        }
        else{
            fileName=fileName+""+year+semester+lessonNumber+".xls";

        }
        File inputWorkbook;
		Workbook w;
        inputWorkbook=new File(fileName);

        try {
            w = Workbook.getWorkbook(inputWorkbook);
            Sheet sheet=w.getSheet(0);
            ArrayList list=new ArrayList();

            for (int i=1;i<sheet.getRows();i++)
                {
                if(sheet.getCell(2, i).getContents()==sheet.getCell(5, i).getContents()){
                }
                else{
                if( questType.equals("core"))
            {
            if(sheet.getCell(0, i).getContents().toString().equals("*")){
            list.add(new Integer(i));
            }
            }
            if( questType.equals("extended"))
            {
            if(sheet.getCell(0, i).getContents().toString().equals("")){
            list.add(new Integer(i));
            }
            }
            
                }
                }

            if("dd".equals(choice)){
               for(int i=0;i<10;i++){
                Cell korean=sheet.getCell(2,Integer.parseInt(list.get(i).toString()));

                session.setAttribute("a"+i,korean.getContents());
                Cell english=sheet.getCell(5,Integer.parseInt(list.get(i).toString()));
                session.setAttribute("q"+i,english.getContents());
                }

                des="dragdrop.html";
            }


            else if("tf".equals(choice)){
                Collections.shuffle(list);
                 Random r=new Random();
                 int count=0;
                  ArrayList list2=new ArrayList();
                 ArrayList quizSet=new ArrayList();
ArrayList answers=new ArrayList();
                for(int i=0;i<list.size();i++){


                 list2.add(list.get(i));
                 quizSet.add(list.get(i));


             }
                 while(!(count>2&&count<6)){
                     count=0;
                     Collections.shuffle(quizSet);

                     for(int i=0;i<10;i++){
                         if(list2.get(i).equals(quizSet.get(i)) ){
                             count++;
                       }
                     }
                 }
                for(int i=0;i<10;i++){
                Cell korean=sheet.getCell(2,Integer.parseInt(list2.get(i).toString()));
                session.setAttribute("a"+i,korean.getContents());
                Cell english=sheet.getCell(5,Integer.parseInt(quizSet.get(i).toString()));
                session.setAttribute("q"+i,english.getContents());
                if(list2.get(i).equals(quizSet.get(i))){
                    answers.add("true" );
                }
                else{
                    answers.add("false" );
                }

            }
session.setAttribute("answers", answers);
des="truefalse.jsp";
        }


        else if("mc".equals(choice)){
              Collections.shuffle(list);
ArrayList answers=new ArrayList();
              Random r=new Random();
              int j=0,value=0,last=0;
              int index=(int)Math.ceil(list.size()/4);
              last=list.size()-index;

              for(int i=0;i<last;i+=4){

                  j=r.nextInt(4)+i;
                   value=Integer.parseInt(list.get(j).toString());
                  Cell english=sheet.getCell(5,value);
                  Cell korean=sheet.getCell(2,value);

              session.setAttribute("q"+i,english.getContents());
              if(answers.size()<10)
                  answers.add(korean.getContents().toString());
              }
                for(int i=0;i<list.size();i++){

                 value=Integer.parseInt(list.get(i).toString());

              Cell korean=sheet.getCell(2,value);
              session.setAttribute("a"+i,korean.getContents());
               }

session.setAttribute("answers",answers);

des="multiplechoice.jsp";
session.setAttribute("list", list);


        }
            else if("fib".equals(choice)){
              Collections.shuffle(list);
              ArrayList answers=new ArrayList();
              Random r=new Random();
              int j=0,value=0,last=0;
              int index=(int)Math.ceil(list.size()/4);
              last=list.size()-index;

              for(int i=0;i<last;i+=4){
                  j=r.nextInt(4)+i;
                  value=Integer.parseInt(list.get(j).toString());
                  Cell sentence=sheet.getCell(6,value);
                  Cell korean=sheet.getCell(2,value);

              session.setAttribute("q"+i,sentence.getContents());
              if(answers.size()<10)
                  answers.add(korean.getContents().toString());
              }
                for(int i=0;i<list.size();i++){
                value=Integer.parseInt(list.get(i).toString());
                Cell korean=sheet.getCell(2,value);
                session.setAttribute("a"+i,korean.getContents());
               }

              session.setAttribute("answers",answers);
              des="fillInTheBlank.jsp";
              session.setAttribute("list", list);
       }
            else{}

        }
        catch (BiffException ex) {
            ex.printStackTrace();
            }
        }

 private void addUser(String hawkid,String fname,String lname,String gender,String studentYear,String duration,String fluency,
         String friends,String family,String yourself) throws ServletException, SQLException, IOException, ClassNotFoundException
   {
        PreparedStatement addUser = null;
        Connection connection=null;
      try
      {   if(connection==null)
          connection=getConnection();
          if (addUser==null)
           addUser = (PreparedStatement) connection.prepareStatement(
                 "insert into users (hawkid,fname,lname,gender,studentYear,duration,fluency, friends,family,yourself) " +
                 "values ('"+hawkid+"','"+fname+"','"+lname+"','"+gender+"','"+studentYear+"','"+duration+"','"+
                 fluency+"','"+friends+"','"+family+"','"+yourself+"');");
         addUser.executeUpdate();
      }
      catch (SQLException e)
      { throw new ServletException(e); }
   }

 private ArrayList getUser(String uip_hawkid) throws ServletException, SQLException, IOException, ClassNotFoundException
 {
     PreparedStatement getUser = null;
        Connection connection=null;
        ArrayList user=new ArrayList();
      try
      {   if(connection==null)
          connection=getConnection();
          if (getUser==null)
              getUser = (PreparedStatement) connection.prepareStatement("select hawkid,fname,lname from users");
          ResultSet results = getUser.executeQuery();
          if(results.wasNull()){    // KiLab database is empty
             user=null;
          }
          else{
          while(results.next()){
              if(results.getString("hawkid").equals(uip_hawkid)){   // user found in KiLab
                user.add(results.getString("hawkid"));
                user.add(results.getString("fname"));
                user.add(results.getString("lname"));
              }
              else{    // user is not registered with KiLab
                  user=null;
              }
        }
          }
          return user;
      }
      catch (SQLException e)
      { throw new ServletException(e); }

 }

    private void addEssay(String yr,String sem,String hid,Timestamp timesubmitted,String english,String korean) throws ServletException, SQLException, IOException, ClassNotFoundException
   {
        PreparedStatement ps = null;
        Connection conn=null;
      try
      {
            if(conn==null)
          conn=getConnection();
          if (ps==null){
           ps = (PreparedStatement) conn.prepareStatement(
                 "insert into essays(year,semester,hawkid,timesubmitted,english,gradeStatus,korean,grade)" +
                 " values('"+yr+"','"+sem+"','"+hid+"','"+timesubmitted+"','"+english+"','No','"+korean+"','-1.0');");
           ps.executeUpdate();
          }
         ps.close();
         conn.close();
      }
      catch (SQLException e)
      { throw new ServletException(e); }
   }

    public void addGradedEssay(int mid,Timestamp timecorrected,String correctedEnglish,String correctedKorean,float grade) throws ServletException, SQLException, IOException, ClassNotFoundException
   {
        PreparedStatement ps = null;
        Connection conn=null;

      try
      {
          if(conn==null)
          conn=getConnection();
          
        if (ps==null)
         ps = (PreparedStatement) conn.prepareStatement(
                 "update essays set gradeStatus='Yes',timecorrected='"+timecorrected+"',correctedenglish='"+
                 correctedEnglish+"',correctedKorean='" +correctedKorean+"',grade='"+grade+"' where id='"+mid+"';");
          System.out.println("********ps="+ps.toString());
         ps.executeUpdate();
        ps.close();
        conn.close();

      }
      catch (SQLException e)
      { throw new ServletException(e); }
   }

   private ArrayList getEssays(String hawkid,String keywords,String startdate,String enddate,String graded) throws ServletException, SQLException, IOException, ClassNotFoundException, java.text.ParseException
    {
    PreparedStatement ps = null;
        Connection connection=null;
      try
      {
          ArrayList essays=new ArrayList();
          String query=null;
          if(connection==null)
          connection=getConnection();
String start=null;
String end=null;
int dd = 0;
            
    if(startdate!=null&&!startdate.isEmpty())
        {
            start=startdate.subSequence(6,10)+"-"+startdate.subSequence(0,2)+"-"+startdate.subSequence(3,5);
        }
    else{}
if(enddate!=null&&!enddate.isEmpty())
    {
        end=enddate.subSequence(6,10)+"-"+enddate.subSequence(0,2)+"-"+enddate.subSequence(3,5);
        
}
else{}
           if(query==null&&hawkid!=null)
           { query="SELECT * from essays where hawkid='"+hawkid+"'";
           }
           else{}
           if (query!=null&&keywords!=null&&!keywords.isEmpty())
           {
               query=query+" and match(hawkid,english,korean,correctedenglish,correctedkorean) against('"+keywords+"' with query expansion)" ;

           }
           if (query!=null&&start!=null&&end!=null)
           {

               query=query+" and timesubmitted>='"+start+"' and timesubmitted<'"+end +"'";
           }
           if (query!=null&&graded!=null&&!graded.isEmpty())
           {
               query=query+" and gradeStatus='"+graded+"';" ;
           }


          
          else{
          essays=new ArrayList();}
          ps = (PreparedStatement) connection.prepareStatement(query);
          ResultSet results = ps.executeQuery();
            while(results.next()){
                EssayBean eb=new EssayBean();
                eb.setYear(results.getString("year"));
                eb.setSemester(results.getString("semester"));
                eb.setHawkID(results.getString("hawkID"));
                eb.setDatesubmitted(results.getTimestamp("timesubmitted"));
                eb.setMid(Integer.parseInt(results.getString("id")));
                eb.setEnglishMessage(results.getString("english"));
                eb.setKoreanMessage(results.getString("korean"));
                eb.setcorrectedEnglishMessage(results.getString("correctedenglish"));
                eb.setcorrectedKoreanMessage(results.getString("correctedkorean"));
                eb.setDatecorrected(results.getTimestamp("timecorrected"));
                eb.setGraded(results.getString("gradeStatus"));
                if(graded==null&eb.getGrade()<0)
                    eb.setGrade(-1);
                else{
                 eb.setGrade(Float.parseFloat(results.getString("grade")));

                }
                essays.add(eb);
              }
          return essays;

      }
   catch (SQLException e)
      { throw new ServletException(e); }

   }


    /*private int gradeMe(ArrayList answers,ArrayList responses){
        int correct=0;
        for(int i=0;i<answers.size();i++){
            if(answers.get(i).equals(responses.get(i))){
                correct++;
            }
            else if(responses.get(i).equals("null")){

            }
            else{}
        }
        return correct;
    }*/
    private void postMail( String recipients[ ], String subject,
                            String message , String from) throws MessagingException
  {
    boolean debug = false;

     //Set the host smtp address
     Properties props = new Properties();
     props.put("mail.smtp.host", SMTP_HOST_NAME);
     props.put("mail.smtp.auth", "true");
props.put("mail.smtp.starttls.enable","true");

    Authenticator auth = new SMTPAuthenticator();
    Session session = Session.getDefaultInstance(props, auth);

    session.setDebug(debug);

    // create a message
    Message msg = new MimeMessage(session);

    // set the from and to address
    InternetAddress addressFrom = new InternetAddress(from);
    msg.setFrom(addressFrom);

    InternetAddress[] addressTo = new InternetAddress[recipients.length];
    for (int i = 0; i < recipients.length; i++)
    {
        addressTo[i] = new InternetAddress(recipients[i]);
    }
    msg.setRecipients(Message.RecipientType.TO, addressTo);


    // Setting the Subject and Content Type
    msg.setSubject(subject);
    msg.setContent(message, "text/plain");
    Transport.send(msg);
 }

    public void sendMail(String year,String semester, String hawkid)
    {
  String to = "dsouzma@gmail.com";
  String from = "dsouzma@gmail.com";
  String host = "smtp.gmail.com";
  String filename = "C:/Users/sharon/Desktop/testing.txt";
  String msgText1 = "Dear Instructor,\n"+
"An essay has been submitted to you for grading via the Korean Language Website. " +
"The details of the student submitting the essay are as follows:\n" +
"HawkID: "+hawkid+"\nYear: "+year+"\n"+
"Semester: "+semester+"\n"+
"The essay being submitted is attached along with this email for your review.\n"+
"Thank You,\n" +
"korean-language@uiowa.edu\n\n\n"+
"This is a automated system generated email from the Korean Language Website. " +
"Please do not respond to this message.\n" +
"/***********\n"+
"The information contained in this message is intended only for the recipient, " +
"and may otherwise be privileged and confidential. If the reader of this message is " +
"not the intended recipient, or an employee or agent responsible for delivering this message " +
"to the intended recipient, please be aware that any dissemination or copying of this " +
"communication is strictly prohibited. If you have received this communication in error, " +
"please immediately notify us by replying to the message and deleting it from your computer.\n"+
"***********/";
  String subject = "A new essay has been submitted from the Korean Language Website";

  // create some properties and get the default Session
//  java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
  Properties props = new Properties();
  props.put("mail.smtp.host", host);
  props.put("mail.smtp.auth", "true");
  props.put("mail.smtp.starttls.enable","true");
  //props.put("mail.smtp.port", "587");



  try
  {   Authenticator auth = new SMTPAuthenticator();
    Session session = Session.getDefaultInstance(props, auth);

    session.setDebug(false);
      // create a message
      MimeMessage msg = new MimeMessage(session);
      msg.setFrom(new InternetAddress(from));
      InternetAddress[] address = {new InternetAddress(to)};
      msg.setRecipients(Message.RecipientType.TO, address);
      msg.setSubject(subject);

      // create and fill the first message part
      MimeBodyPart mbp1 = new MimeBodyPart();
      mbp1.setText(msgText1);

      // create the second message part
     // MimeBodyPart mbp2 = new MimeBodyPart();

            // attach the file to the message
      /*FileDataSource fds = new FileDataSource(filename);
      mbp2.setDataHandler(new DataHandler(fds));
      mbp2.setFileName(fds.getName());*/

      // create the Multipart and add its parts to it
    /*  Multipart mp = new MimeMultipart();
      mp.addBodyPart(mbp1);
      mp.addBodyPart(mbp2);*/

      // add the Multipart to the message
      //msg.setContent(mp);

      // set the Date: header
      msg.setSentDate(new java.util.Date());
       msg.setSubject(subject);

    // Send message with authentication!

Transport tr = session.getTransport("smtp");
//tr.connect("email.uiowa.edu",587 ,"mfdsouza", "^^fd$ouza");
tr.connect("smtp.gmail.com" ,"dsouzma", "pepsiblu");
msg.saveChanges(); // don't forget this
tr.sendMessage(msg, msg.getAllRecipients());
tr.close();

Transport.send(msg);

  }
  catch (MessagingException mex)
  {
      mex.printStackTrace();
      Exception ex = null;
      if ((ex = mex.getNextException()) != null) {
    ex.printStackTrace();
      }
  }

    }


    private class SMTPAuthenticator extends javax.mail.Authenticator
{

    public PasswordAuthentication getPasswordAuthentication()
    {
        String username = SMTP_AUTH_USER;
        String password = SMTP_AUTH_PWD;
        return new PasswordAuthentication(username, password);
    }
}
   public static Connection getConnection() throws SQLException, IOException, ClassNotFoundException
   {
     String file="C:/Users/Mark/Documents/NetBeansProjects/XmlQuiz/src/java/db.prop";
      Properties props = new Properties();
      FileInputStream in = new FileInputStream(file);
      props.load(in);
      in.close();

      String drivers = props.getProperty("jdbc.drivers");
      if (drivers != null)
	 System.setProperty("jdbc.drivers", drivers);
      String url = props.getProperty("jdbc.url");
      String username = props.getProperty("jdbc.username");
      String password = props.getProperty("jdbc.password");
      
      
      Class.forName(drivers);
      return DriverManager.getConnection(url, username, password);
   }
    }
