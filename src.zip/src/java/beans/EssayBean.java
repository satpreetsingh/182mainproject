package beans;


import java.io.Serializable;
import java.util.Date;
import java.sql.*;

public class EssayBean implements Serializable{

    private String year;
    private String semester;
    private String hawkID;
    private String fname;
    private String lname;
    private int mid;
    private String koreanMessage;
    private String englishMessage;
    private String correctedKoreanMessage;
    private String correctedEnglishMessage;
    private String graded;
    private float grade;

    private Timestamp datesubmitted,datecorrected;

    public Timestamp getDatecorrected() {
        return datecorrected;
    }

    public void setDatecorrected(Timestamp datecorrected) {
        this.datecorrected = datecorrected;
    }

    public Timestamp getDatesubmitted() {
        return datesubmitted;
    }

    public void setDatesubmitted(Timestamp datesubmitted) {
        this.datesubmitted = datesubmitted;
    }

    public float getGrade() {
        return grade;
    }

    public void setGrade(float grade) {
        this.grade = grade;
    }


   
    


public String getEnglishMessage() {
        return englishMessage;
    }

    public void setEnglishMessage(String englishMessage) {
        this.englishMessage = englishMessage;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getGraded() {
        return graded;
    }

    public void setGraded(String graded) {
        this.graded = graded;
    }

    public String getHawkID() {
        return hawkID;
    }

    public void setHawkID(String hawkID) {
        this.hawkID = hawkID;
    }

    public String getKoreanMessage() {
        return koreanMessage;
    }

    public void setKoreanMessage(String koreanMessage) {
        this.koreanMessage = koreanMessage;
    }

    public String getcorrectedEnglishMessage(){
         return correctedEnglishMessage;
    }

    public void setcorrectedEnglishMessage(String correctedenglishMessage){
        this.correctedEnglishMessage=correctedenglishMessage;
    }

    public void setcorrectedKoreanMessage(String correctedkoreanMessage){
        this.correctedKoreanMessage=correctedkoreanMessage;
    }

    public String getcorrectedKoreanMessage(){
         return correctedKoreanMessage;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }



}
