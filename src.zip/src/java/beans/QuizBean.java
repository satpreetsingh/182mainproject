package beans;


import java.io.Serializable;
import java.util.Date;
import java.sql.*;
import java.util.ArrayList;

public class QuizBean implements Serializable{

    private int mid,year,semester,lesson;

    
private String type=null;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    public int getLesson() {
        return lesson;
    }

    public void setLesson(int lesson) {
        this.lesson = lesson;
    }

private ArrayList questions,answers,responses,list2,quizSet,position;

    public ArrayList getPosition() {
        return position;
    }

    public void setPosition(ArrayList position) {
        this.position = position;
    }

    
    public ArrayList getList2() {
        return list2;
    }

    public void setList2(ArrayList list2) {
        this.list2 = list2;
    }

    public ArrayList getQuizSet() {
        return quizSet;
    }

    public void setQuizSet(ArrayList quizSet) {
        this.quizSet = quizSet;
    }

    public ArrayList getQuestions() {
        return questions;
    }

    public void setQuestions(ArrayList questions) {
        this.questions = questions;
    }

    public ArrayList getAnswers() {
        return answers;
    }

    public void setAnswers(ArrayList answers) {
        this.answers = answers;
    }

    public ArrayList getResponses() {
        return responses;
    }

    public void setResponses(ArrayList responses) {
        this.responses = responses;
    }

   

 public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    
}
