package messages;       // messages/UserBean.java

public class UserBean implements java.io.Serializable
{
   private String name;
   private String password;

   public UserBean()
   { }

   public UserBean(String n, String p)
   { name = n;  password = p; }

   public void setName(String n)
   { name = n;  }
   
   public String getName()
   { return name;  }

   public void setPassword(String p)
   { password = p; }

   public String getPassword()
   { return password;  }
}
