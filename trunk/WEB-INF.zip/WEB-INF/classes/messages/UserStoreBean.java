package messages;       // messages/UserStoreBean.java

import java.sql.*;
import javax.servlet.ServletException;

public class UserStoreBean implements java.io.Serializable
{
   private Connection connection;
   private PreparedStatement addUser, getUser, getName,
                             getUsers, changePW, deleteUser;
   
   public UserStoreBean() { }

   public void setConnection(Connection c) throws ServletException
   {  connection = c;  }
   
   public boolean findUser(String n, String p) throws ServletException
   {
      try
      {  if (getUser==null)
            getUser = connection.prepareStatement(
                     "select name from Users where name=? and password=?");
         getUser.setString(1, n);
         getUser.setString(2, p);
         ResultSet rs = getUser.executeQuery();
         return rs.next();
      }
      catch (SQLException e) 
      { throw new ServletException(e); }
   }
   
   public boolean findUser(String n) throws ServletException
   {
      try
      {  if (getName==null)
            getName = connection.prepareStatement(
                              "select name from Users where name=?");
         getName.setString(1, n);
         ResultSet rs = getName.executeQuery();
         return rs.next();
      }
      catch (SQLException e) 
      { throw new ServletException(e); }
   }
   
   public void addUser(UserBean ub) throws ServletException
   {
      try
      {  if (addUser==null)
            addUser = connection.prepareStatement(
                       "insert into Users (name, password) values (?, ?)");
         addUser.setString(1, ub.getName());
         addUser.setString(2, ub.getPassword());
         addUser.executeUpdate();
      }
      catch (SQLException e) 
      { throw new ServletException(e); }
   }

   public void setPassword(String n, String p) throws ServletException
   {
      try
      {  if (changePW==null)
           changePW = connection.prepareStatement(
                         "update Users set password=? where name=?");
         changePW.setString(1, p);
         changePW.setString(2, n);
         changePW.executeUpdate();
      }
      catch (SQLException e) 
      { throw new ServletException(e); }
   }

   public void removeUser(String n) throws ServletException
   {
      try
      {  if (deleteUser==null)
            deleteUser = connection.prepareStatement(
                            "delete from Users where name=?");
         deleteUser.setString(1, n);
         deleteUser.executeUpdate();
      }
      catch (SQLException e) 
      { throw new ServletException(e); }
   }

   public String getUsers() throws ServletException
   {
      try
      {  if (getUsers==null)
            getUsers = connection.prepareStatement(
                     "select name,password from Users");
         StringBuffer sb = new StringBuffer("<hr size='5'/>");
         sb.append("<table bgcolor='white' border='3' ");
         sb.append("width='250px' cellpadding='6'>");
   
         ResultSet results = getUsers.executeQuery();
         while (results.next()) 
         {
            String name = results.getString(1);
            sb.append("<tr><td>");
            sb.append(results.getString(1));
            sb.append("</td></tr>");
         }         
         sb.append("</table><hr size='5'/>");
         return sb.toString(); 
      }
      catch (SQLException e) 
      { throw new ServletException(e); }
   }
   
   protected void finalize() throws SQLException
   { getUser.close(); getName.close(); 
     addUser.close(); getUsers.close();
   }
}
