package messages;            // messages/MessageServlet.java

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class MessageServlet extends HttpServlet
{
   private DataSourceBean dsb;   // these classes are
   private UserStoreBean usb;    // in the same package
   private MessageStoreBean msb;

   public void init() throws ServletException
   {
      dsb = new DataSourceBean();
      dsb.setDriver(getServletContext().getInitParameter("jdbc.drivers"));
      dsb.setUrl(getServletContext().getInitParameter("jdbc.url"));
      dsb.setUsername(getServletContext().getInitParameter("jdbc.username"));
      dsb.setPassword(getServletContext().getInitParameter("jdbc.password"));

      usb = new UserStoreBean();
      msb = new MessageStoreBean();
      usb.setConnection(dsb.getConnection());
      msb.setConnection(dsb.getConnection());
   }

   public void doGet(HttpServletRequest request,
                     HttpServletResponse response) 
                             throws ServletException, IOException
   {
      String des = "/notes/mboard.jsp";
      HttpSession session = request.getSession();
      session.setAttribute("dsbean", dsb);
      session.setAttribute("usbean", usb);
      session.setAttribute("msbean", msb);

      if (request.getParameter("choice") != null)
      {
         String choice = request.getParameter("choice");
         if ("login".equals(choice))
            des = "/notes/messageboard/login.jsp";
         else if ("register".equals(choice))
            des = "/notes/messageboard/register.jsp";
      }
      else if (request.getParameter("Logout") != null)
          session.invalidate();
      else if (request.getParameter("option") != null
                                     && !session.isNew())
      {
         String name = (String)session.getAttribute("name");
         String opt = request.getParameter("option");
         if ("add".equals(opt))
            des = "/notes/messageboard/add.jsp";
         else if ("viewall".equals(opt))
            des = "/notes/messageboard/viewall.jsp";
         else if ("viewtodays".equals(opt))
            des = "/notes/messageboard/todays.jsp";
         else if ("list".equals(opt))
            des = "/notes/messageboard/list.jsp";
         else if ("changepw".equals(opt))
            des = "/notes/messageboard/password.jsp";
         else if ("unregister".equals(opt))
            usb.removeUser(name);
      }
      else if (request.getParameter("Logout") != null)
          session.invalidate();
      else if (request.getParameter("Cancel") != null
                                     && !session.isNew())
         des = "/notes/messageboard/options.jsp"; 
      else if (request.getParameter("vaReturn") != null)
      {
         String [] deletes = request.getParameterValues("deletes");
         if (deletes != null)
         for (int k=0; k<deletes.length; k++)
            msb.deleteMessage(Integer.parseInt(deletes[k]));
         des = "/notes/messageboard/options.jsp"; 
      }

      RequestDispatcher disp = request.getRequestDispatcher(des);
      disp.forward(request, response);
   }

   public void doPost(HttpServletRequest request,
                      HttpServletResponse response) 
                             throws ServletException, IOException
   { 
      String des = "/notes/mboard.jsp";
      HttpSession session = request.getSession();
      session.setAttribute("dsbean", dsb);
      session.setAttribute("usbean", usb);
      session.setAttribute("msbean", msb);

      if (request.getParameter("Login") != null)
      {
         String name = request.getParameter("name").trim();
         String password = request.getParameter("password").trim();

         if (usb.findUser(name, password))
         {
             session.setAttribute("name", name);
             session.setAttribute("password", password);
             des = "/notes/messageboard/options.jsp";
         }
         else
             des = "/WEB-INF/messageboard/logerror.jsp";
      }
      else if (request.getParameter("Register") != null)
      {
         String name = request.getParameter("name").trim();
         String password = request.getParameter("password").trim();
         
         if (!usb.findUser(name))
         {
             if ("".equals(name) || password.length()<5)
                des = "/WEB-INF/messageboard/pwerror.jsp";
             else
             {
                session.setAttribute("name", name);
                session.setAttribute("password", password);
                usb.addUser(new UserBean(name,password));
                des = "/notes/messageboard/options.jsp";
             }
         }
         else
             des = "/WEB-INF/messageboard/regerror.jsp"; 
      }
      else if (request.getParameter("AddMessage") != null
                                       && !session.isNew())
      {
         String name = (String)session.getAttribute("name");
         Calendar cal = Calendar.getInstance();
         java.util.Date date = cal.getTime();
         long millis = date.getTime();
         Timestamp ts = new Timestamp(millis);
         String message = request.getParameter("message");
         msb.addMessage(new MessageBean(name, ts, message));
         des = "/notes/messageboard/options.jsp"; 
      }
      else if (request.getParameter("NewPassword") != null
                                         && !session.isNew())
      {
         String name = (String)session.getAttribute("name");
         String oldpw = request.getParameter("oldpw").trim();
         String newpw1 = request.getParameter("newpw1").trim();
         String newpw2 = request.getParameter("newpw2").trim();
         if (usb.findUser(name, oldpw) 
                 && newpw1.equals(newpw2) && newpw1.length()>=5) 
         {
             session.setAttribute("password", newpw1);
             usb.setPassword(name, newpw1);
             des = "/notes/messageboard/options.jsp";
         }
         else
             des = "/WEB-INF/messageboard/newpwerror.jsp";
      }

      RequestDispatcher disp = request.getRequestDispatcher(des);
      disp.forward(request, response);
   }
}
