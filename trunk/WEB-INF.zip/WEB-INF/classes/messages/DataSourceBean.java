package messages;     // messages/DataSourceBean.java

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.io.Serializable;
import javax.servlet.ServletException;
 
/* A simple data source bean for getting database connections.  */

public class DataSourceBean implements Serializable
{
   public void setDriver(String driver) throws ServletException 
   {  
       try
       {  Class.forName(driver); 
       }
       catch (ClassNotFoundException e)
       {  throw new ServletException(e); }
   }

   public void setUrl(String aUrl)
   { url = aUrl; }

   public void setUsername(String aUsername)
   { username = aUsername; }

   public void setPassword(String aPassword)
   { password = aPassword; }

   public Connection getConnection() throws ServletException
   {  
      try
      {
	 if (connection == null)
	   connection = DriverManager.getConnection(url, username, password);
	 return connection;
      }	
      catch (SQLException e)
      {  throw new ServletException(e);  }
   }

   private String url;
   private String username;
   private String password;
   private Connection connection;
}
