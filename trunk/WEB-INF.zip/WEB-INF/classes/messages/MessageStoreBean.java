package messages;       // messages/MessageStoreBean.java

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;

public class MessageStoreBean implements Serializable
{
   private Connection connection;
   private PreparedStatement addMessage, getAll, getTodays, delMessage;
   private String userName = "none"; 
   
   public MessageStoreBean() { }

   public void setConnection(Connection c)
   {  connection = c;  }

   public String getTodaysMessages() throws ServletException
   {
      Calendar start = Calendar.getInstance();
      start.set(Calendar.HOUR_OF_DAY, 0);
      start.set(Calendar.MINUTE, 0);
      start.set(Calendar.SECOND, 0);
      start.set(Calendar.MILLISECOND, 0);
      java.util.Date date = start.getTime();
      long millis = date.getTime();
      Timestamp today = new Timestamp(millis);

      StringBuffer sb = new StringBuffer("<hr size='5'/>");
      sb.append("<pre>");

      try
      {  if (getTodays==null)
           getTodays = connection.prepareStatement(
                        "select mid, name, tstamp, message from Messages "
                      + "where tstamp >= ? order by tstamp desc");
         getTodays.setTimestamp(1, today);
         int num = 0;
         ResultSet results = getTodays.executeQuery();
         while (results.next()) 
         {
            String messageName = results.getString(2);
            sb.append("<i>Source of message:</i>&nbsp;" + messageName);
            sb.append("\n<i>Time of message:</i>&nbsp;" + results.getTimestamp(3));
            num++;
            sb.append("\n<i>Message " + num + ":</i>\n");
            sb.append(results.getString(4));
/***********
         BufferedReader br = new BufferedReader(
                              new InputStreamReader(results.getAsciiStream(4)));
         String line = br.readLine();
         while (line != null)
         {
            sb.append(line + "\n");
            line = br.readLine();
         }
***********/
            sb.append("<p>");
            String mid = results.getString(1);
            if (messageName.equals(userName))
              sb.append("<input type='checkbox' name='deletes' "
                                           + "value='"+mid+"'/>Delete");
            sb.append("</p>");
            sb.append("<hr size='5'/>");
         }         
         if (num == 0) sb.append("<h2>No messages today.</h2>");
         sb.append("</pre>");
         return sb.toString(); 
      }
      catch (SQLException e) 
      { throw new ServletException(e); }
   }
   
   public String getMessages() throws ServletException
   {
      StringBuffer sb = new StringBuffer("<hr size='5'/>");
      sb.append("<pre>");

      try
      {  if (getAll==null)
           getAll = connection.prepareStatement(
                      "select mid, name, tstamp, message from Messages "
                    + "order by tstamp desc");
         int num = 0;
         ResultSet results = getAll.executeQuery();
         while (results.next()) 
         {
            String messageName = results.getString(2);
            sb.append("<i>Source of message:</i>&nbsp;" + messageName);
            sb.append("\n<i>Time of message:</i>&nbsp;" + results.getTimestamp(3));
            num++;
            sb.append("\n<i>Message " + num + ":</i>\n");
            sb.append(results.getString(4));
            sb.append("<p>");
            String mid = results.getString(1);
            if (messageName.equals(userName))
              sb.append("<input type='checkbox' name='deletes' "
                                           + "value='"+mid+"'/>Delete");
            sb.append("</p>");
            sb.append("<hr size='5'/>");
         }         
         if (num == 0) sb.append("<h2>No messages.</h2>");
         sb.append("</pre>");
         return sb.toString(); 
      }
      catch (SQLException e) 
      { throw new ServletException(e); }
   }
   
   public void addMessage(MessageBean mb) throws ServletException
   {
      try
      {  if (addMessage==null)
           addMessage = connection.prepareStatement(
                 "insert into Messages ( " +
                    "name, tstamp, message) values ( ?, ?, ?)");
         addMessage.setString(1, mb.getName());
         addMessage.setTimestamp(2, mb.getTimeStamp());
         String str = mb.getMessage();
         byte [] bytes = str.getBytes();
         ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
         addMessage.setAsciiStream(3, bais, bytes.length);
         addMessage.executeUpdate();
      }
      catch (SQLException e) 
      { throw new ServletException(e); }
   }

   public void deleteMessage(int mid) throws ServletException
   {
      try
      {  if (delMessage==null)
           delMessage = connection.prepareStatement(
                 "delete from Messages where mid=?");
         delMessage.setInt(1, mid);
         delMessage.executeUpdate();
      }
      catch (SQLException e) 
      { throw new ServletException(e); }
   }

   public void setUserName(String n)
   { userName = n; }

   protected void finalize() throws SQLException
   { getAll.close(); getTodays.close(); addMessage.close(); }
}
