package messages;    // messages/MessageBean.java

import java.sql.Timestamp;

public class MessageBean implements java.io.Serializable
{
   private String name;
   private Timestamp timeStamp;
   private String message;

   public MessageBean()
   { }

   public MessageBean(String n, Timestamp ts, String m)
   {
      name = n; timeStamp = ts; message = m;
   }

   public void setName(String n)
   { name = n;  }
   
   public String getName()
   { return name;  }

   public void setTimeStamp(Timestamp ts)
   { timeStamp = ts;  }

   public Timestamp getTimeStamp()
   { return timeStamp;  }

   public void setMessage(String m)
   { message = m; }

   public String getMessage()
   { return message;  }
}
 
