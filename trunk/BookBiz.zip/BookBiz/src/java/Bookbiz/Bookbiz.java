package Bookbiz;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;
import java.text.DecimalFormat;

public class Bookbiz extends HttpServlet 
{
   private Connection con;

   public void init() throws ServletException
   {  
      try 
      {   Class.forName("com.mysql.jdbc.Driver");
      } 
      catch (ClassNotFoundException e) 
      {	throw new ServletException(e); }

      //String url = "jdbc:mysql://localhost/mysql";
      //String uid = "root", pw = "root";
      String url = "jdbc:mysql://at-lamp.its.uiowa.edu/koreanlab_lmc";
      String uid = "koreanlab_u", pw = "korlab2009";
      try 
      {   con = DriverManager.getConnection(url, uid, pw);
      } 
      catch (SQLException e)
      {	throw new ServletException("SQLException1: " + e); }
   }

   public void doGet(HttpServletRequest req, HttpServletResponse res)
      	                throws ServletException, IOException
   {  
      res.setContentType("text/html");
      PrintWriter out = res.getWriter();
      
      out.print("<html><head><title>Bookbiz</title></head>");

      if (con == null)
         out.print("<body><h2>Unable to connect to DB</h2></body></html>");
      else
         try 
         {  Statement st = con.createStatement();
            String q = "select titleID, title from Titles";
            ResultSet rs = st.executeQuery(q);

            out.print("<body>");
            out.print("<h2>Choose a book title.</h2>");
            out.print("<form method=\"post\" action=\"Bookbiz\">");
            out.print("<select name=\"titleID\">");
            while (rs.next())
            {
               out.print("<option value=\"" + rs.getString(1) + "\">");
               out.print(rs.getString(2)+"</option>");
            }
            out.print("</select>");
            out.print("<p><input type=\"submit\" name=\"details\"/>");
            out.print("</p></form>");
            out.print("</body></html>");
         } 
         catch (SQLException e) 
         {  throw new ServletException("SQLException2: " + e); }
   }

   public void doPost(HttpServletRequest req, HttpServletResponse res)
                              throws ServletException, IOException 
   { 
      String titleID, price;
      res.setContentType("text/html");
      PrintWriter out = res.getWriter();
      if (req.getParameter("details") != null)
      {
         out.print("<html><head><title>Book Details</title></head>");
         titleID = req.getParameter("titleID");
         String title=null, pubID=null, pubName=null;
         try 
         {  Statement st = con.createStatement();

            String q = "select title, pubID from Titles"
                                 + " where titleID=\"" + titleID + "\"";
            ResultSet rs = st.executeQuery(q);
            if (rs.next())
            {
                title = rs.getString("title");
                pubID = rs.getString("pubID");
            }
            rs.close();
            price = getPrice(titleID);
	    if (price == null) 
	        price = "0.00";     // price may be null in DB

            q = "select pubName from Publishers where pubID=\"" + pubID + "\"";
            rs = st.executeQuery(q);
            if (rs.next())
                pubName = rs.getString("pubName");
            rs.close();

            out.print("<body><h2>Book Information Summary<h2/>");
            out.print("<h3>Title: " + title + "<br/>");
            out.print("Publisher: " + pubName + "<br/>");
            out.print("Price: " + price + "<br/>");
            out.print("<p>Authors: </h3><ol><h4>");
            q = "select auFname, auLname, auOrd from " +
                          " Authors, TitleAuthors where " +
                          " Authors.auID=TitleAuthors.auID " + 
                          " and TitleAuthors.titleID=\"" +
                          titleID + "\" order by auOrd";
            rs = st.executeQuery(q);
            while (rs.next())
            {
               String first = rs.getString("auFname");
               String last = rs.getString("auLname");
               out.print("<li>" + first + " " + last + "</li>");
            }
            rs.close();
            out.print("</h4></ol></p></h3>");
         }
         catch (SQLException e) 
         {  throw new ServletException("SQLException3: " + e); }

         out.print("<hr/><form method=\"post\" action=\"Bookbiz\">");
         out.print("<p>Change price?<br/>");
         out.print("<input type=\"text\" value=\"0.00\" " +
                   "size=\"6\"name=\"amount\"/>");
         out.print("<input type=\"submit\" value=\"Increase\" name=\"inc\"/>");
         out.print("<input type=\"submit\" value=\"Decrease\" name=\"dec\"/>");
         out.print("<input type=\"hidden\" name=\"titleID\" value=\"" 
                                                  + titleID + "\"/>");
         out.print("<input type=\"hidden\" name=\"price\" value=\"" 
                                                  + price + "\"/>");
         out.print("</p></form>");
      }
      else
      {  out.print("<html><head><title>New Price</title></head>");
         String amount = req.getParameter("amount");
         titleID = req.getParameter("titleID");
         price = req.getParameter("price");
         double a = 0.0;
         try
         {   a = Double.parseDouble(amount);
         }
         catch (NumberFormatException e) { }
         if (a > 0.0)
         {
            if (req.getParameter("dec") != null) a = -a;
            double nPrice = Double.parseDouble(price);
            nPrice = Math.max(0.0, nPrice+a);
            setPrice(titleID, nPrice); 
            out.print("<body><h3>Changing the price to $");
            out.print(format(nPrice) + "</h3>");
         }
         else out.print("<body><h3>No change in the price.</h3>");
      }
      out.print("<form method=\"get\" action=\"Bookbiz\">");
      out.print("<p><input type=\"submit\" value=\"Return\"/>");
      out.print("</p></form></body></html>");
   } 

   synchronized String getPrice(String titleID) throws ServletException
   {
       String price = "";
       try 
       {
          Statement st = con.createStatement();
          String q = "select price from Titles"
                               + " where titleID=\"" + titleID + "\"";
          ResultSet rs = st.executeQuery(q);
          if (rs.next())
            price = rs.getString("price");
          rs.close();
       }
       catch (SQLException e) 
       {  throw new ServletException("SQLException4: " + e); }
       return price;
   }

   synchronized void setPrice(String titleID, double p) 
                                     throws ServletException
   {
       try 
       {  Statement st = con.createStatement();
          p = Math.rint(p*100.0)/100.0;
          String q = "update Titles set price= \"" + p 
                             + "\" where titleID=\"" + titleID + "\"";
          int r = st.executeUpdate(q);
       }
       catch (SQLException e) 
       {  throw new ServletException("SQLException5: " + e); }
   }

   String format(double d)
   {
        DecimalFormat df = new DecimalFormat("##0.00");
        return df.format(d);
   }

   public void destroy()
   {   try 
       {  if (con != null) con.close();
       }
       catch (SQLException e) { }
   }
}
