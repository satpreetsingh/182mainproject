package Bookbiz;



import java.sql.*;
//import java.io.*;
import java.util.Scanner;

public class MySql
{
   public static void main(String [] args)
   { 
      try
      {  
         System.setProperty("jdbc.drivers", "com.mysql.jdbc.Driver");

         String url = "jdbc:mysql://localhost/mysql";

         Connection con =  
                DriverManager.getConnection(url, "root", "root");

         Statement stmt = con.createStatement();

         Scanner scan = new Scanner(System.in);

         System.out.println("Enter MySQL commands terminated by ;");
         System.out.println("Enter commands in lowercase.");
         System.out.println("Use \"quit;\" to exit.");

         while (true)
         {
             System.out.print("\nmysql> ");
             String cmd = scan.nextLine().trim();
             while (cmd.indexOf(';') == -1)
             {
                 System.out.print("    -> ");
                 cmd = cmd + " " + scan.nextLine().trim();
             }

             if (cmd.startsWith("quit"))
               break;
 
             if (cmd.startsWith("show tables"))
             {
                 DatabaseMetaData dbmd = con.getMetaData();
                 ResultSet rs = 
                     dbmd.getTables(null,null,null,new String [] {"TABLE"});
                 System.out.println("-------------------------------");
                 int count = 0;
                 while (rs.next())
                 {
                     System.out.println(rs.getString(3));
                     count++;
                 }
                 System.out.println("-------------------------------");
                 System.out.println(count + " rows in set");
                 rs.close();
             }
             else if (cmd.startsWith("select")
		         || cmd.startsWith("describe"))
             {
                 ResultSet rs = stmt.executeQuery(cmd);
                 ResultSetMetaData rsmd = rs.getMetaData();
                 int columnCount = rsmd.getColumnCount();

                 for (int k=1; k<=columnCount; k++)
                 {
                     if (k>1) System.out.print(", ");
                     System.out.print(rsmd.getColumnName(k));
                 }
                 System.out.println();
                 System.out.println("-------------------------------");

                 int count = 0;
                 while (rs.next())
                 {
                     for (int k = 1; k <= columnCount; k++)
                     {
                         if (k > 1) System.out.print(", ");
                         System.out.print(rs.getString(k));
                     }
                     System.out.println();
                     count++;
                 }
                 System.out.println("-------------------------------");
                 System.out.println(count + " rows in set");
                 rs.close();
             }
             else
             {
                 int count = stmt.executeUpdate(cmd);
                 System.out.println("-------------------------------");
                 System.out.println("Rows changed = " + count);
             }
         }   // while (true)

         System.out.println("Goodbye");
         scan.close(); stmt.close(); con.close();
      }
      catch (SQLException ex)
      {  System.out.println ("SQLException:" + ex); }
   }
}
