package Bookbiz;



import java.sql.*;

public class CreateTable
{
  public static void main(String[] args)
  {
    try
    {
       Connection conn = getConnection();
 
       Statement create = conn.createStatement();
       
       create.executeUpdate(
          "insert into Publishers values('0736','New Age Books','1 1st St','Boston','MA');");
 
       conn.close();
    }
    catch (ClassNotFoundException e)
    { System.out.println(e); }
    catch (SQLException e)
    { System.out.println(e); }
  }

  static Connection getConnection() 
                 throws ClassNotFoundException, SQLException
  {
      String user   = "root";
      String passwd = "root";
      String url    = "jdbc:mysql://localhost/mysql";
      String driver = "com.mysql.jdbc.Driver";
 
      Class.forName(driver);
      return DriverManager.getConnection(url, user, passwd);
  }
}

