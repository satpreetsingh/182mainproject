fixMozillaZIndex=true; //Fixes Z-Index problem  with Mozilla browsers but causes odd scrolling problem, toggle to see if it helps
_menuCloseDelay=500;
_menuOpenDelay=150;
_subOffsetTop=2;
_subOffsetLeft=-2;




with(menuStyle=new mm_style()){
bordercolor="#296488";
borderstyle="solid";
borderwidth=1;
fontfamily="Verdana, Tahoma, Arial";
fontsize="75%";
fontstyle="normal";
headerbgcolor="#ffffff";
headercolor="#000000";
offbgcolor="#DCE9F0";
offcolor="#515151";
onbgcolor="#4F8EB6";
oncolor="#ffffff";
outfilter="randomdissolve(duration=0.3)";
overfilter="Fade(duration=0.2);Alpha(opacity=90);Shadow(color=#777777', Direction=135, Strength=5)";
padding=5;
pagebgcolor="#82B6D7";
pagecolor="black";
separatorcolor="#2D729D";
separatorsize=1;
subimage="http://img.milonic.com/arrow.gif";
subimagepadding=2;
}

with(milonic=new menuname("Main Menu")){
alwaysvisible=1;
orientation="horizontal";
style=menuStyle;
aI("fontsize=8px;text=Home;tooltip=This is a link to the Home Page;url=http://www.milonic.com/;");
aI("fontsize=10px;showmenu=Samples;text=Menu Samples;tooltip=This is a link to the Menu Samples page, note that you can also include <b><i>HTML</i></b> in tooltips;");
aI("fontsize=12px;fontstyle=italic;showmenu=Milonic;text=Milonic;tooltip=You can include images: <img src=http://www.milonic.com/images/penfold_over.gif> as well as line breaks<br>This<br>is<br>something<br>that<br>you<br>cannot<br>do<br>with<br>the<br>standard<br>tooltips;");
aI("fontsize=14px;showmenu=Partners;text=Partners;tooltip=Tooltips are easily added to your menu items<br>just add <b style='font-size:1em'>tooltip=Your tooltip text;</b> to the menu items aI string;");
aI("fontsize=16px;pointer=move;showmenu=Links;text=Links;tooltip=`Dont forget that you'll need the tooltips.js module.<br><br>This can be found at http://www.milonic.com/tooltips.js<br><br>You then need to add a script reference like this:<br>&lt;script type=\\\"text/javascript\\\" src=\\\"/milonic_src.js\\\"&gt;&lt;/s;");
aI("fontsize=18px;fontstyle=italic;showmenu=My Milonic;text=My Milonic;tooltip=Double and single quotes are possible too.<br>Don't forget to TRIPLE escape the double quotes<br>and also enclose the tooltip text in back ticks <br>if you are including semi colons<br>Adding Semi colons to the menu text causes it<br>to break continuity w;");
}

with(milonic=new menuname("Samples")){
overflow="scroll";
style=menuStyle;
aI("text=Plain Text Horizontal Style DHTML Menu Bar;url=http://www.milonic.com/menusample1.php;tooltip=The most common of menu samples. This<br>sample allows for vertical pulldown menus<br>to appear from a horizontal main menu;")
aI("text=Vertical Plain Text Menu;url=http://www.milonic.com/menusample2.php;tooltip=Another common sample This time, the sub<br>menus are opened from a vertical main menu ;")
aI("text=Using The Popup Menu Function Positioned by Images;url=http://www.milonic.com/menusample24.php;tooltip=The popup function can also open menus<br>based on mouse action but also positioned<br>relative to an image ;")
aI("text=Classic XP Style Menu;url=http://www.milonic.com/menusample82.php;")
aI("text=XP Style;url=http://www.milonic.com/menusample86.php;")
aI("text=Office XP Style Menu;url=http://www.milonic.com/menusample47.php;")
aI("text=Office 2003 Style Menu;url=http://www.milonic.com/menusample46.php;")
aI("text=Apple Mac Style Menu;url=http://www.milonic.com/menusample72.php;")
aI("text=Amazon Style Tab Menu;url=http://www.milonic.com/menusample74.php;")
aI("text=Milonic Home Menu;url=http://www.milonic.com/menusample78.php;")
aI("text=Windows 98 Style Menu;url=http://www.milonic.com/menusample13.php;tooltip=The Microfost Windows 98 3D look & feel can be<br>acheived by adding high and low 3D colors to<br>your menu styles ;")
aI("text=Multiple Styles Menu;url=http://www.milonic.com/menusample5.php;tooltip=Demonstrating how to declare properties using different<br>menu styles. Separate styles can be declared for each<br>menu ora style can be used globally for every menu ;")
aI("text=Multi Colored Menu Items;url=http://www.milonic.com/menusample80.php;")
aI("text=Multi Colored Menus Using Styles;url=http://www.milonic.com/menusample7.php;tooltip= ;")
aI("text=Multi Tab;url=http://www.milonic.com/menusample50.php;")
aI("text=Tab Top;url=http://www.milonic.com/menusample52.php;")
aI("text=Multi Columns;url=http://www.milonic.com/menusample73.php;")
aI("text=100% Width Span Menu;url=http://www.milonic.com/menusample26.php;tooltip=Spanning the menu to 100% of the browser width<br>will allow for the menu to become a page separator ;")
aI("text=Follow Scrolling Style Menu;url=http://www.milonic.com/menusample10.php;tooltip=Keeping the menu available at all times no matter<br>where your user has scrolled to, can be acheived by<br>setting the followscroll property for your main menu ;")
aI("text=Menu Positioning With Offsets;url=http://www.milonic.com/menusample23.php;tooltip=Setting the position of menus using screenposition<br>is a handy way of ensuring that your menus will<br>always be centered or positioned exactly how<br>you need ;")
aI("text=Table Based (Relative) Menus;url=http://www.milonic.com/menusample9.php;tooltip=Positioning menus relative to your web pages<br>flow can be acheived by setting the menu style<br>property position to relative ;")
aI("text=Opening Windows and Frames with the Menu;url=http://www.milonic.com/menusample11.php;tooltip=Opening links in other windows or other frames<br>is easy by using the target menu item property. ;")
aI("text=Menus Over Form Selects, Flash and Java Applets;url=http://www.milonic.com/menusample14.php;tooltip=Older browsers have a problem with form objects<br>and other HTML objects that naturally sit higher in<br>the browser layer hiding the menu.<br>The workaround fr this is to use DIV hiding ;")
aI("text=Activating Functions on Mouseover;url=http://www.milonic.com/menusample15.php;tooltip=onfunction, offfunction and clickfunction are<br>built in features that allow you to add<br>custom JavaScript to several menu events ;")
aI("text=Drag Drop Menus;url=http://www.milonic.com/menusample22.php;tooltip=By setting your menus type to be <b>draggable</b><br>this will allow for your users to move<br>main menus by drag and drop ;")
aI("text=Menus with Header Type Items;url=http://www.milonic.com/menusample8.php;tooltip=If you need to separate blocks of menu items within<br>a single menu, Headers are a handy way of<br>segragating your menu items ;")
aI("text=Right To Left Openstyle;url=http://www.milonic.com/menusample65.php;")
aI("text=Up Openstyle Featuring Headers;url=http://www.milonic.com/menusample33.php;")
aI("text=DHTML Menus and Tooltips;url=http://www.milonic.com/menusample6.php;tooltip=Tooltips are a handy way of adding more information<br>informing the user how to navigate your website or<br>use your application incorporating the menu ;")
aI("text=Unlimited Level Menus Example;url=http://www.milonic.com/menusample67.php;")
aI("text=Context Right Click Menu;url=http://www.milonic.com/menusample27.php;tooltip=Context menus are easily configured with the<br>Milonic DHTML Menu. No special requirements are needed<br>Except for a small custom JavaScript module ;")
aI("text=Menus built entirely from images;url=http://www.milonic.com/menusample18.php;tooltip=If you prefer to build your menus completely<br>from images this is easily possible, let<br>the menu take care of your images. ;")
aI("text=Static Images Sample;url=http://www.milonic.com/menusample16.php;tooltip=Inserting images inside menus is made easy<br>with the use of the image property for menu items ;")
aI("text=Rollover Swap Images Sample;url=http://www.milonic.com/menusample17.php;tooltip=Swaping images on mouse over can be acheived<br>by setting the image and onimage properties<br>for your menu items ;")
aI("text=Background Item Images;url=http://www.milonic.com/menusample20.php;tooltip=Each menu item can have its own background image.<br>Text can be overlaid meaning you only need to build<br>and download one image ;")
aI("text=Background Image Buttons;url=http://www.milonic.com/menusample89.php;")
aI("text=Menu Background Images;url=http://www.milonic.com/menusample76.php;")
aI("text=Creating Texture with Menu Background Images;url=http://www.milonic.com/menusample19.php;tooltip=Adding a background image to your menus can<br> vastly improve the apperance of otherwise dull<br>backgrounds. ;")
aI("text=Static Background Item Images;url=http://www.milonic.com/menusample71.php;")
aI("text=Vertical Static Background Item Images;url=http://www.milonic.com/menusample87.php;")
aI("text=World Map Sample;url=http://www.milonic.com/menusample92.php;")
aI("text=US Map Sample;url=http://www.milonic.com/menusample91.php;")
aI("text=Image Map Sample;url=http://www.milonic.com/menusample4.php;tooltip=Image maps can be used to open menus using the popup<br>function based on the HTML object AREA ;")
aI("text=Rounded Edges Imperial Style;url=http://www.milonic.com/menusample21.php;tooltip=Including rounded edges to menus ;")
aI("text=Corporation;url=http://www.milonic.com/menusample40.php;")
aI("text=International;url=http://www.milonic.com/menusample70.php;")
aI("text=Clean;url=http://www.milonic.com/menusample32.php;")
aI("text=3D Gradient Block;url=http://www.milonic.com/menusample57.php;")
aI("text=Descreet;url=http://www.milonic.com/menusample42.php;")
aI("text=Agriculture;url=http://www.milonic.com/menusample41.php;")
aI("text=Breeze;url=http://www.milonic.com/menusample29.php;")
aI("text=Chart;url=http://www.milonic.com/menusample66.php;")
aI("text=Cartoon;url=http://www.milonic.com/menusample77.php;")
aI("text=Start Button Menu;url=http://www.milonic.com/menusample69.php;")
aI("text=Tramline;url=http://www.milonic.com/menusample54.php;")

}

with(milonic=new menuname("Milonic")){
style=menuStyle;
aI("text=Product Purchasing Page;url=http://www.milonic.com/cbuy.php;");
aI("text=Contact Us;url=http://www.milonic.com/contactus.php;");
aI("text=Newsletter Subscription;url=http://www.milonic.com/newsletter.php;");
aI("text=FAQ;url=http://www.milonic.com/menufaq.php;");
aI("text=Discussion Forum;url=http://www.milonic.com/forum/;");
aI("text=Software License Agreement;url=http://www.milonic.com/license.php;");
aI("text=Privacy Policy;url=http://www.milonic.com/privacy.php;");
}

with(milonic=new menuname("Partners")){
style=menuStyle;
aI("text=(aq) Web Hosting;url=http://www.a-q.co.uk/;");
aI("text=SMS 2 Email;url=http://www.sms2email.com/;");
aI("text=WebSmith;url=http://www.softidiom.com/?milonicmenu;");
}

with(milonic=new menuname("Links")){
style=menuStyle;
aI("text=Apache Web Server;url=http://www.apache.org/;");
aI("text=MySQL Database Server;url=http://ww.mysql.com/;");
aI("text=PHP - Development;url=http://www.php.net/;");
aI("text=phpBB Web Forum System;url=http://www.phpbb.net/;");
aI("showmenu=Anti Spam;text=Anti Spam Tools;");
}

with(milonic=new menuname("Anti Spam")){
style=menuStyle;
aI("text=Spam Cop;url=http://www.spamcop.net/;");
aI("text=Mime Defang;url=http://www.mimedefang.org/;");
aI("text=Spam Assassin;url=http://www.spamassassin.org/;");
}

with(milonic=new menuname("My Milonic")){
style=menuStyle;
aI("text=Login;url=http://www.milonic.com/login.php;");
aI("text=Licenses;url=http://www.milonic.com/mylicenses.php;");
aI("text=Invoices;url=http://www.milonic.com/myinvoices.php;");
aI("text=Make Support Request;url=http://www.milonic.com/reqsupport.php;");
aI("text=View Support Requests;url=http://www.milonic.com/mysupport.php;");
aI("text=Your Details;url=http://www.milonic.com/mydetails.php;");
}

drawMenus();

